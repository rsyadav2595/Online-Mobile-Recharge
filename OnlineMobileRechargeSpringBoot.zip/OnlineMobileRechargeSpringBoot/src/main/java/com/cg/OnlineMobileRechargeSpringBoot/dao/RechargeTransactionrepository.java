package com.cg.OnlineMobileRechargeSpringBoot.dao;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.OnlineMobileRechargeSpringBoot.dto.RechargeTransaction;
import com.cg.OnlineMobileRechargeSpringBoot.dto.Wallet;

public interface RechargeTransactionrepository  extends JpaRepository<RechargeTransaction, BigInteger >{

	public RechargeTransaction save(Wallet wall);

}
