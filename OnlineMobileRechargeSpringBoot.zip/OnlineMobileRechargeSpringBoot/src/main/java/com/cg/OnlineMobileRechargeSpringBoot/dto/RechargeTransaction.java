package com.cg.OnlineMobileRechargeSpringBoot.dto;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RechargeTransaction {

	@Id
	@Column(name = "transId")
	private BigInteger TransactionId;

	@Column(name = "amount")
	private Double amount;

	private String mobileno;

	public RechargeTransaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RechargeTransaction(BigInteger transactionId, Double amount, String mobileno) {

		TransactionId = transactionId;
		this.amount = amount;
		this.mobileno = mobileno;
		// this.wallet = wallet;
	}

	public BigInteger getTransactionId() {
		return TransactionId;
	}

	public void setTransactionId(BigInteger transactionId) {
		TransactionId = transactionId;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	/*
	 * public Wallet getWallet() { return wallet; } public void setWallet(Wallet
	 * wallet) { this.wallet = wallet; }
	 */
	@Override
	public String toString() {
		return "RechargeTransaction [TransactionId=" + TransactionId + ", amount=" + amount + ", mobileno=" + mobileno
				+ "]";
	}
}
