package com.cg.OnlineMobileRechargeSpringBoot.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Customer {

	/*
	 * Written by Radhika Yadav on 5/25/2019 last modified on 5/25/2019 this is
	 * customer dto
	 * 
	 */

	@Column(name = "customer_name")
	private String name;

	@Id
	@Column(name = "customer_emailid")
	private String email;

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_email")
	private List<Mobile> mobiles = new ArrayList<>();;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(String name, String email, List<Mobile> mobiles) {
		super();
		this.name = name;
		this.email = email;
		this.mobiles = mobiles;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Mobile> getMobiles() {
		return mobiles;
	}

	public void setMobiles(List<Mobile> mobiles) {
		this.mobiles = mobiles;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", email=" + email + ", mobiles=" + mobiles + "]";
	}

}
