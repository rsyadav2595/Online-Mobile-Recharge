package com.cg.OnlineMobileRechargeSpringBoot.dao;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.OnlineMobileRechargeSpringBoot.dto.Customer;
import com.cg.OnlineMobileRechargeSpringBoot.dto.Mobile;
import com.cg.OnlineMobileRechargeSpringBoot.dto.RechargeTransaction;
import com.cg.OnlineMobileRechargeSpringBoot.dto.Wallet;

public interface MobileRechargeRepository extends JpaRepository<Customer, String> {

}
/*
 * Written by Radhika Yadav on 5/25/2019 
 * last modified on 5/25/2019 
 * MobileRechargeRepository extends  
 * JpaRepository
 * 
 */





// Customer save(Customer custm);

// public Customer save(Customer custm);
// public Wallet saveWallet(Wallet wall) ;

// @Query("FROM Mobile WHERE mobiles=:mobileno")
// public Customer findByMobileno(String mobiles);

// public RechargeTransaction saveTransaction(Wallet wall) ;
