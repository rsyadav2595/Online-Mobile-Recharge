package com.cg.OnlineMobileRechargeSpringBoot.service;

import com.cg.OnlineMobileRechargeSpringBoot.dto.Customer;
import com.cg.OnlineMobileRechargeSpringBoot.dto.Mobile;
import com.cg.OnlineMobileRechargeSpringBoot.dto.RechargeTransaction;
import com.cg.OnlineMobileRechargeSpringBoot.dto.Wallet;
import com.cg.OnlineMobileRechargeSpringBoot.exception.Mobilerechargeexception;

public interface MobileRechargeService {
	
	public Customer addCustomer(Customer custm);
    public Wallet  topupBalance(Wallet wall);
	public Mobile searchByMobileno(String mobileno) throws Mobilerechargeexception;
    public  RechargeTransaction rechargeMobile(Wallet wall) ;
}
