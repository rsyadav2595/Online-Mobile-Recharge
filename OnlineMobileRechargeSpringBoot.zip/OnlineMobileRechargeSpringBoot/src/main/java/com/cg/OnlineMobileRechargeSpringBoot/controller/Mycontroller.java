package com.cg.OnlineMobileRechargeSpringBoot.controller;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.OnlineMobileRechargeSpringBoot.dto.Customer;
import com.cg.OnlineMobileRechargeSpringBoot.dto.Mobile;
import com.cg.OnlineMobileRechargeSpringBoot.dto.RechargeTransaction;
import com.cg.OnlineMobileRechargeSpringBoot.dto.Wallet;
import com.cg.OnlineMobileRechargeSpringBoot.exception.Mobilerechargeexception;
import com.cg.OnlineMobileRechargeSpringBoot.service.MobileRechargeService;

//@Controller
@RestController
@RequestMapping("/onlinemob")
public class Mycontroller {
	
	public static final Logger logger=Logger.getLogger(Mycontroller.class);

	@Autowired
	MobileRechargeService service;

	Customer customer;
	Wallet wall;

	@RequestMapping(value = "/addcustomer", method = RequestMethod.POST)
	public ResponseEntity<Customer> addcustomer(@ModelAttribute Customer cust) {
		Customer custm = service.addCustomer(cust);
		if (custm == null) {
			return new ResponseEntity("custmer not addeed", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Customer>(custm, HttpStatus.OK);

	}

	@RequestMapping(value = "/addwallet", method = RequestMethod.POST)
	public ResponseEntity<Wallet> addwallet(@ModelAttribute Wallet wall) {

		Wallet wallet = service.topupBalance(wall);
		if (wallet == null) {
			return new ResponseEntity("wallet not addeed", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Wallet>(wallet, HttpStatus.OK);

	}

	@RequestMapping(value = "/search/{mobileno}", method = RequestMethod.GET)
	public ResponseEntity<Mobile> findbymobileno(@PathVariable("mobileno") String mobileno) {
		Mobile mob;
		try {
			mob= service.searchByMobileno(mobileno);
		}catch (Mobilerechargeexception e) {
			return new ResponseEntity(e.getMessage(),HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Mobile>(mob, HttpStatus.OK);
		
	}

}

/*
 * @RequestMapping(value = "/addtran", method = RequestMethod.POST) public
 * RechargeTransaction addTransaction(@RequestBody Wallet wall) {
 * service.rechargeMobile(wall);
 * 
 * return null;
 * 
 * }
 */
/*
 * @RequestMapping(value="/addAll",method=RequestMethod.POST) //one to one
 * public ResponseEntity<Customer> addAll(@ModelAttribute Customer cust) {
 * 
 * 
 * Customer custm=service.addCustomer(cust); if(custm==null) { return new
 * ResponseEntity("custmer not addeed",HttpStatus.NOT_FOUND); } return new
 * ResponseEntity<Customer>(custm,HttpStatus.OK);
 * 
 * }
 * 
 */

/*
 * @RequestMapping(value="/addmobile",method=RequestMethod.POST) //one to many
 * public
 * ResponseEntity<Customer>custmermanymobile(@RequestParam("mobileno")String
 * mobileno,
 * 
 * @RequestParam("operator") String operator) {
 * 
 * 
 * Mobile mobii=new Mobile(); List<Mobile> mobilist = new ArrayList<>();
 * 
 * mobii.setMobileno(mobileno); mobii.setOperator(operator);
 * mobii.setCustomer(customer);
 * 
 * 
 * 
 * mobilist.add(mobii); Customer customerone = new Customer();
 * customerone.setName(customer.getName());
 * customerone.setEmail(customer.getEmail());
 * 
 * customerone.setMobiles(mobilist);
 * 
 * Customer customer = service.addCustomer(customerone);
 * 
 * return new ResponseEntity<Customer>(customer,HttpStatus.OK);
 * 
 * }
 * 
 */

/*
 * public ResponseEntity<RechargeTransaction>
 * rechargemobile(@RequestParam("TransactionId")BigInteger TransactionId,
 * 
 * @RequestParam("amount")Double amount,@RequestParam("mobileno")String
 * mobileno) {
 * 
 * 
 * RechargeTransaction transaction=new RechargeTransaction();
 * List<RechargeTransaction>mylist=new ArrayList<>();
 * 
 * transaction.setAmount(amount); transaction.setMobileno(mobileno);
 * transaction.setTransactionId(TransactionId);
 * 
 * 
 * 
 * mylist.add(transaction);
 * 
 * Wallet wallet=new Wallet(); wallet.setBalance(wall.getBalance());
 * wallet.setCustomer(wall.getCustomer());
 * wallet.setTransaction(wall.getTransaction());
 * wallet.setWalletId(wall.getWalletId()); RechargeTransaction
 * walletone=service.rechargeMobile(wallet);
 * 
 * wallet.setTransaction(mylist); return new
 * ResponseEntity<RechargeTransaction>(transaction,HttpStatus.OK);
 * 
 * }
 */
