package com.cg.OnlineMobileRechargeSpringBoot.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.OnlineMobileRechargeSpringBoot.controller.Mycontroller;
import com.cg.OnlineMobileRechargeSpringBoot.dao.MobileRechargeRepository;
import com.cg.OnlineMobileRechargeSpringBoot.dao.RechargeTransactionrepository;
import com.cg.OnlineMobileRechargeSpringBoot.dao.Searchmobilerepository;
import com.cg.OnlineMobileRechargeSpringBoot.dao.WalletRepository;
import com.cg.OnlineMobileRechargeSpringBoot.dto.Customer;
import com.cg.OnlineMobileRechargeSpringBoot.dto.Mobile;
import com.cg.OnlineMobileRechargeSpringBoot.dto.RechargeTransaction;
import com.cg.OnlineMobileRechargeSpringBoot.dto.Wallet;
import com.cg.OnlineMobileRechargeSpringBoot.exception.Mobilerechargeexception;

@Service
public class MobileRechargeServiceImpl implements MobileRechargeService {

	@Autowired
	MobileRechargeRepository repository;

	@Autowired
	WalletRepository repositorayone;

	@Autowired
	RechargeTransactionrepository repo;

	@Autowired
	Searchmobilerepository repos;

	@Override
	public Customer addCustomer(Customer custm) {
		if (Mycontroller.logger.isDebugEnabled()) {
			Mycontroller.logger.debug("addMobileRechargeService  addCustomer(Customer) is executed!");
		}
		return repository.save(custm);
	}
	
	
	/**@author Radhika
     * Wrote on 24-05-2019
	 * last modified on 27-05-2019
	 *interact with MobileRechargeRepository to retrieve the records using Customer name email
	 *  @return Customer
	 *  @throws com.cg.BootEmployeeDepartmentDetails.exception.IdNotFoundException if data not found
	 */ 
	
	
	 @Override
	public Wallet topupBalance(Wallet wall) {
		if (Mycontroller.logger.isDebugEnabled()) {
			Mycontroller.logger.debug("addMobileRechargeService  topupBalance(Wallet) is executed!");
		}
		return repositorayone.save(wall);
	}


		/**@author Radhika
	     * Wrote on 24-05-2019
		 * last modified on 27-05-2019
		 *interact with MobileRechargeRepository to retrieve the records using Wallet ie wallet id,balnce customer details
		 *  @return Wallet 
		 */ 

	@Override
	public Mobile searchByMobileno(String mobileno) throws Mobilerechargeexception
	{
		if (Mycontroller.logger.isDebugEnabled()) {
			Mycontroller.logger.debug("addMobileRechargeService  searchByMobileno(String) is executed!");
		}
		Mobile mob= repos.findByMobileno(mobileno);
		if(mob==null)
		{
			Mycontroller.logger.error(new Mobilerechargeexception());
			throw new Mobilerechargeexception("mobile notfound");
		}

		return mob;

	}
	
	
	/**@author Radhika
     * Wrote on 24-05-2019
	 * last modified on 27-05-2019
	 *interact with MobileRechargeRepository to search mobile no
	 *  @return Mobile
	 *  @throws com.cg.Mobilerechargeexception.exception.Mobilenotfound if data not found
	 */ 

	@Override
	public RechargeTransaction rechargeMobile(Wallet wall)
	{

		if (Mycontroller.logger.isDebugEnabled())
		{
			Mycontroller.logger.debug("addMobileRechargeService  rechargeMobile(Wallet) is executed!");
		}

		return repo.save(wall);

	}
	/**@author Radhika
     * Wrote on 24-05-2019
	 * last modified on 27-05-2019
	 *interact with MobileRechargeRepository to recharge specific mobile 
	 *  @return Wallet
      */ 

}
