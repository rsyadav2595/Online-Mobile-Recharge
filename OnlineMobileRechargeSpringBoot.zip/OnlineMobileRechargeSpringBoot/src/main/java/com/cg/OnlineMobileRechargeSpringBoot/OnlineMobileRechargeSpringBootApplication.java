package com.cg.OnlineMobileRechargeSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
//@ComponentScan("com.cg.OnlineMobileRechargeSpringBoot")
public class OnlineMobileRechargeSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineMobileRechargeSpringBootApplication.class, args);
	System.out.println("Heloo spring boot");
	}

}
