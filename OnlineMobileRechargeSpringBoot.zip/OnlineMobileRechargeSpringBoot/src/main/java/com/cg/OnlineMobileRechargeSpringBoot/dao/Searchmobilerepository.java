package com.cg.OnlineMobileRechargeSpringBoot.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.OnlineMobileRechargeSpringBoot.dto.Customer;
import com.cg.OnlineMobileRechargeSpringBoot.dto.Mobile;

public interface Searchmobilerepository  extends JpaRepository<Mobile, String>{

	 public Mobile findByMobileno(String mobileno);

}
