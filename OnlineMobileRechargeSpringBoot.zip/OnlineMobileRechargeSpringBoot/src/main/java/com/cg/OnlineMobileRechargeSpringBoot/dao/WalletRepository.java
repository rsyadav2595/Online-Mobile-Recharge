package com.cg.OnlineMobileRechargeSpringBoot.dao;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.OnlineMobileRechargeSpringBoot.dto.Wallet;

public interface WalletRepository extends JpaRepository<Wallet,BigInteger> {

	 //  public Wallet save(Wallet wall);

	
}
