package com.cg.OnlineMobileRechargeSpringBoot.exception;

public class Mobilerechargeexception extends RuntimeException {

	public Mobilerechargeexception()
	{
		
	}
	
	
	public Mobilerechargeexception(String msg)
	{
		super(msg);
	}
	
}
