package com.cg.OnlineMobileRechargeSpring.dto;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("custm")
@Scope("prototype")
public class Customer {

	private String name;
	private String email;

	private List<Mobile> mobiles;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Customer(String name, String email, List<Mobile> mobiles) {
		super();
		this.name = name;
		this.email = email;
		this.mobiles = mobiles;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Mobile> getMobiles() {
		return mobiles;
	}

	public void setMobiles(List<Mobile> mobiles) {
		this.mobiles = mobiles;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", email=" + email + ", mobiles=" + mobiles + "]";
	}

}
