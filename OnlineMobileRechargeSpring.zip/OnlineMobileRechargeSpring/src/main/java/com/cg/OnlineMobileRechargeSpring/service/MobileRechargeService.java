package com.cg.OnlineMobileRechargeSpring.service;

import java.math.BigInteger;

import com.cg.OnlineMobileRechargeSpring.dto.Customer;
import com.cg.OnlineMobileRechargeSpring.dto.RechargeTransaction;
import com.cg.OnlineMobileRechargeSpring.dto.Wallet;
import com.cg.OnlineMobileRechargeSpring.exception.Mobilerechargeexception;

public interface MobileRechargeService
{
	public boolean addCustomer(Customer custm);
    public Wallet  topupBalance(Wallet wall);
    public Customer searchByMobileno(BigInteger mobileno)throws Mobilerechargeexception;
    public  RechargeTransaction rechargeMobile(Wallet wall) ;

}
