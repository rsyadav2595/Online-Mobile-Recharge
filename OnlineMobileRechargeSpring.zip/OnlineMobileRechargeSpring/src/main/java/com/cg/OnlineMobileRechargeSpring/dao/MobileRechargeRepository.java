package com.cg.OnlineMobileRechargeSpring.dao;

import java.math.BigInteger;

import com.cg.OnlineMobileRechargeSpring.dto.Customer;
import com.cg.OnlineMobileRechargeSpring.dto.RechargeTransaction;
import com.cg.OnlineMobileRechargeSpring.dto.Wallet;
import com.cg.OnlineMobileRechargeSpring.exception.Mobilerechargeexception;

public interface MobileRechargeRepository {
	public boolean save(Customer custm);
	public Wallet saveWallet(Wallet wall);
	 public Customer findByMobileno(BigInteger mobileno)throws Mobilerechargeexception;
	 public RechargeTransaction saveTransaction(Wallet wall) ;
	 
	 
}
