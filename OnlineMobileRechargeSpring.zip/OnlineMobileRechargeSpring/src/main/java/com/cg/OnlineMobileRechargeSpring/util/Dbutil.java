package com.cg.OnlineMobileRechargeSpring.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.OnlineMobileRechargeSpring.dto.Customer;
import com.cg.OnlineMobileRechargeSpring.dto.Mobile;
import com.cg.OnlineMobileRechargeSpring.dto.RechargeTransaction;
import com.cg.OnlineMobileRechargeSpring.dto.Wallet;

public class Dbutil {

	public static List<Mobile> mylist = new ArrayList<Mobile>();
	public static List<Customer> custmlistOne = new ArrayList<Customer>();
	public static List<Wallet> walletlist=new ArrayList<Wallet>();
	public static List<RechargeTransaction>transactionlist=new ArrayList<RechargeTransaction>();

}
/*
	static {

		Mobile mobi =  new Mobile(new BigInteger("9421956709"), new String("idea"));
		Mobile mobione = new Mobile(new BigInteger("98657935"), new String("vodafone"));
		Mobile mobitwo = new Mobile(new BigInteger("8424008665"), new String("jio"));

		mylist.add(mobi);
		mylist.add(mobione);
		mylist.add(mobitwo);

		Customer custmone = new Customer("Radhika", "radha@gmail.com", mylist);
		
		RechargeTransaction trans=new RechargeTransaction(new BigInteger("1001"),852.3,new BigInteger("9421956709"));
		RechargeTransaction tranone=new RechargeTransaction(new BigInteger("1002"),852.3,new BigInteger("8424008665"));
		
		transactionlist.add(trans);
		transactionlist.add(tranone);
		
		
		Wallet wallet=new Wallet( 200.2,new BigInteger("5555"),custmone,transactionlist);
		
		
		MobileRechargeServiceImpl service = new MobileRechargeServiceImpl();

		service.addCustomer(custmone);
	

	}

}
*/