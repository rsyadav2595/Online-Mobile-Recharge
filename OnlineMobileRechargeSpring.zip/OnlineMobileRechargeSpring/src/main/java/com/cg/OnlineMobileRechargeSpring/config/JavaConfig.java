package com.cg.OnlineMobileRechargeSpring.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/*
 * Written by Radhika Yadav on 5/14/2019 last modified on 5/14/2019 
 * the class javaconfig is used  to configure all the classes under  com.cg.OnlineMobileRechargeSpring package
 */
@Configuration
@ComponentScan("com.cg.OnlineMobileRechargeSpring")
public class JavaConfig {

}
