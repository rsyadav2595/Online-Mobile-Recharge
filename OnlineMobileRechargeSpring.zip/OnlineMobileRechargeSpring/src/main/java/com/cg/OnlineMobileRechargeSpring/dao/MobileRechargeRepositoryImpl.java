package com.cg.OnlineMobileRechargeSpring.dao;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.OnlineMobileRechargeSpring.dto.Customer;
import com.cg.OnlineMobileRechargeSpring.dto.Mobile;
import com.cg.OnlineMobileRechargeSpring.dto.RechargeTransaction;
import com.cg.OnlineMobileRechargeSpring.dto.Wallet;
import com.cg.OnlineMobileRechargeSpring.exception.Mobilerechargeexception;
import com.cg.OnlineMobileRechargeSpring.util.Dbutil;

@Repository("mobilerechargerepository")
public class MobileRechargeRepositoryImpl implements MobileRechargeRepository {

	public boolean save(Customer custm) {

		Dbutil.custmlistOne.add(custm);
		return true;
		// return false;
	}

	/*
	 * Written by Radhika Yadav on 5/14/2019 last modified on 5/14/2019 save method
	 * is used for saving Customer data like name emailid,mobileno.
	 */

	public Wallet saveWallet(Wallet wall) {

		Dbutil.walletlist.add(wall);

		return wall;
	}

	/*
	 * Written by Radhika Yadav on 5/14/2019 lats modified on 5/14/2019 save method
	 * is used for saving all wallet data
	 */
	public Customer findByMobileno(BigInteger mobileno) throws Mobilerechargeexception {

		for (Customer cust : Dbutil.custmlistOne) {

			for (Mobile mobile : cust.getMobiles()) {

				if (mobile.getMobileno().equals(mobileno)) {
					return cust;

				}
				throw new Mobilerechargeexception("mobile not found");
			}
		}
		return null;

	}
	/*
	 * Written by Radhika Yadav on 5/14/2019 last modified on 5/14/2019
	 * findByMobileno is used for searching customer mobile no from list
	 */

	public RechargeTransaction saveTransaction(Wallet wall) {
		RechargeTransaction wallet = null;
		Dbutil.transactionlist.add(wallet);
		return wallet;

	}
	/*
	 * Written by Radhika Yadav on 5/14/2019 last modified on 5/14/2019
	 * saveTransaction is used for saving transaction of mobile recharge
	 */

}
