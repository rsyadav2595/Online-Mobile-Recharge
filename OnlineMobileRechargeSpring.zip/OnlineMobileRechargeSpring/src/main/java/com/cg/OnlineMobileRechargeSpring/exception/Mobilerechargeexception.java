package com.cg.OnlineMobileRechargeSpring.exception;

public class Mobilerechargeexception extends RuntimeException {

	public Mobilerechargeexception()
	{
		
	}
	
	public Mobilerechargeexception(String msg)
	{
		super(msg);
	}
	
}
