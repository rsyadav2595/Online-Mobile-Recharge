package com.cg.onlinemobilerechargespringmvc.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.apache.jasper.tagplugins.jstl.core.ForEach;
import org.springframework.stereotype.Repository;


import com.cg.onlinemobilerechargespringmvc.dto.Customer;
import com.cg.onlinemobilerechargespringmvc.dto.Mobile;
import com.cg.onlinemobilerechargespringmvc.dto.RechargeTransaction;
import com.cg.onlinemobilerechargespringmvc.dto.Wallet;

@Repository
public class MobileRechargeRepositoryImpl implements MobileRechargeRepository 
{

	@PersistenceContext
	  EntityManager em ;

	@Override
	public boolean save(Customer custm) 
	{
		System.out.println("In Dao "+custm);
		//Customer customerone=getCustomers(custm.getMobiles());
	      Customer cuobj= em.find(Customer.class, custm.getEmail());
		if(cuobj==null)
		{
			em.persist(custm);
			em.flush();
		}else {
			//Mobile mobii=new Mobile();
			//mobii.setMobileno(custm.getMobiles().get(0).getMobileno());
			//mobii.setOperator(mobii.getOperator());
			//mobii.setCustomer(customerone);
			List<Mobile> mylist=custm.getMobiles();
			for(Mobile obj:mylist)
			{
			em.persist(obj);
			em.flush();
			}
		}
				return true;
	}

    
	public  Customer getCustomers(List<Mobile> mobiles)   //List<Mobile>
	{
		Customer custo=null;
		
		Query query=em.createQuery("FROM Mobile WHERE mobileno=:mobileno");
		query.setParameter("mobileno",mobiles);   ///get(0).getMobileno()
		 custo=(Customer)query.getSingleResult();
		 //em.persist(mobiles);
		// em.flush();
		return custo;
		}

	@Override
	public Wallet saveWallet(Wallet wall) {
		   em.persist(wall);
		   em.flush();
		   return wall;
	}

	@Override
	public Customer findByMobileno(String mobileno) 
	{
		System.out.println("hfj");

		   List<Mobile>mobilelist =new ArrayList<Mobile>();
		   Customer custm=null;
		 //  em.persist(mobileno);
           String sql="FROM Mobile WHERE mobileno=:mobileno";
		   TypedQuery<Mobile>query=em.createQuery(sql,Mobile.class);
   		   query.setParameter("mobileno", mobileno);
	       Mobile mobilesearch=query.getSingleResult();
	       
	    		 
	       return custm;

		
	}

	@Override
	public RechargeTransaction saveTransaction(Wallet wall)
	{
		
		System.out.println("hiiii");
		RechargeTransaction Wallet = null;
		
		
		Wallet wallone=em.find(Wallet.class,wall.getWalletId());
	//	RechargeTransaction transt=em.find(RechargeTransaction.class,wall.getWalletId());
		
		if(wall==null) {
			em.persist(wallone);
			em.flush();
			
		}else {
			List<RechargeTransaction> translist=wall.getTransaction();
	        for(RechargeTransaction objone:translist) {
	        	
	        	em.persist(objone);
	        	em.flush();
	        }
		}
		return Wallet;
		
		
		//return Wallet;
		
		
		
		
		/*RechargeTransaction Wallet = null;
		List<RechargeTransaction> transaction=wall.getTransaction();
	em.persist(transaction);
	// RechargeTransaction transactionone=null;
	 for (RechargeTransaction rechargeTransaction : transaction) {
	
	  Query query=em.createNativeQuery("INSERT INTO rechargetransaction VALUES (?,?,?,?)");
	
	   query.setParameter(1, rechargeTransaction.getTransactionId());
       query.setParameter(2, rechargeTransaction.getAmount());
	   query.setParameter(3, wall.getWalletId());
	   query.setParameter(4, rechargeTransaction.getMobileno());
	   query.executeUpdate();
	  em.flush();
	*/
	 //}
	
	//return Wallet;

	}
	
	

	
}
