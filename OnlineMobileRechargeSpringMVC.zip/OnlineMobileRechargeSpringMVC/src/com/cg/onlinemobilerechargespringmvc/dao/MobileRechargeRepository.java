package com.cg.onlinemobilerechargespringmvc.dao;



import com.cg.onlinemobilerechargespringmvc.dto.Customer;
import com.cg.onlinemobilerechargespringmvc.dto.RechargeTransaction;
import com.cg.onlinemobilerechargespringmvc.dto.Wallet;


public interface MobileRechargeRepository {

	
	
	public boolean save(Customer custm);
	public Wallet saveWallet(Wallet wall)   ;
    public Customer findByMobileno(String mobileno)     ;
    public RechargeTransaction saveTransaction(Wallet wall)   ;
}
