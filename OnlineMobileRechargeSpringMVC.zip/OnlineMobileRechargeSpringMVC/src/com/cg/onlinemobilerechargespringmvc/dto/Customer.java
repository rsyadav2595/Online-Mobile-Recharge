package com.cg.onlinemobilerechargespringmvc.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;



@Entity
public class Customer 
{

	

	@Id
	@Column(name="customer_emailid")
	private String email;

	@Column(name="customer_name")
	private String name;
	
	@OneToMany(cascade=CascadeType.ALL)
   @JoinColumn(name="customer_email")
	private List<Mobile> mobiles=new ArrayList<>();

	
	public Customer(String email, String name, List<Mobile> mobiles) {
		super();
		this.email = email;
		this.name = name;
		this.mobiles = mobiles;
	}
	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Mobile> getMobiles() {
		return mobiles;
	}

	public void setMobiles(List<Mobile> mobiles) {
		this.mobiles = mobiles;
	}

	@Override
	public String toString() {
		return "Customer [email=" + email + ", name=" + name + ", mobiles=" + mobiles + "]";
	}

}
