package com.cg.onlinemobilerechargespringmvc.dto;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class RechargeTransaction {
	
	
	
	public RechargeTransaction(BigInteger transactionId, double amount, String mobileno, Wallet wallet) {
		super();
		TransactionId = transactionId;
		this.amount = amount;
		this.mobileno = mobileno;
		this.wallet = wallet;
	}


	@Id
	@Column(name="transId")
	private BigInteger TransactionId;
	
	@Column(name="amount")
	private Double amount;
	
	private String mobileno;
	
	@ManyToOne
	@JoinColumn(name="walletId")
	private Wallet wallet;
	
	
	public RechargeTransaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public BigInteger getTransactionId() {
		return TransactionId;
	}
	public void setTransactionId(BigInteger transactionId) {
		TransactionId = transactionId;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}


	@Override
	public String toString() {
		return "RechargeTransaction [TransactionId=" + TransactionId + ", amount=" + amount + ", mobileno=" + mobileno
				+ ", wallet=" + wallet + "]";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
