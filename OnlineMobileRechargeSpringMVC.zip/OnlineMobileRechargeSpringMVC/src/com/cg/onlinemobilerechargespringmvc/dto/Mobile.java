package com.cg.onlinemobilerechargespringmvc.dto;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Mobile
{
	
	
	public Mobile(String mobileno, String operator, Customer customer) 
	{
		super();
		this.mobileno = mobileno;
		this.operator = operator;
		this.customer = customer;
	}


	@Id
	@Column(name="mobileno")
	private  String mobileno;
	
	@Column(name="operator")
	private String operator;
	
	@ManyToOne
	@JoinColumn(name="customer_email")
	private Customer customer;
	
	
	public Mobile() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getMobileno() {
		return mobileno;
	}


	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}


	public String getOperator() {
		return operator;
	}


	public void setOperator(String operator) {
		this.operator = operator;
	}


	public Customer getCustomer() {
		return customer;
	}


	public void setCustomer(Customer customer) {
		this.customer = customer;
	}


	@Override
	public String toString() {
		return "Mobile [mobileno=" + mobileno + ", operator=" + operator + ", customer=" + customer + "]";
	}
	
	
}
