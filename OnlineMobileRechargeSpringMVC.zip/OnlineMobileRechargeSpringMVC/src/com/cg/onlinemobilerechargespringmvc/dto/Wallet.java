package com.cg.onlinemobilerechargespringmvc.dto;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
public class Wallet {

	
	@Id
	private BigInteger walletId;
	
	@OneToOne
    @JoinColumn(name="customer_emailid")
	private Customer customer;
	
	
	 @OneToMany(cascade= CascadeType.ALL)
	 @JoinColumn(name="walletId")
	private List<RechargeTransaction> transaction;
	
	@Column(name="balance")
	private Double balance;
	
	
	public Wallet() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Wallet(Double balance, BigInteger walletId, Customer customer, List<RechargeTransaction> transaction) {
		super();
		this.balance = balance;
		this.walletId = walletId;
		this.customer = customer;
		this.transaction = transaction;
	}

    public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	public BigInteger getWalletId() {
		return walletId;
	}
	public void setWalletId(BigInteger walletId) {
		this.walletId = walletId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public List<RechargeTransaction> getTransaction() {
		return transaction;
	}
	public void setTransaction(List<RechargeTransaction> transaction) {
		this.transaction = transaction;
	}
	@Override
	public String toString() {
		return "Wallet [balance=" + balance + ", walletId=" + walletId + ", customer=" + customer + ", transaction="
				+ transaction + "]";
	} 
	
}
