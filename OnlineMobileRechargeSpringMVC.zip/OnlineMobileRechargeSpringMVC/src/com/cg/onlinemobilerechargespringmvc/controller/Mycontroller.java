package com.cg.onlinemobilerechargespringmvc.controller;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.onlinemobilerechargespringmvc.dto.Customer;
import com.cg.onlinemobilerechargespringmvc.dto.Mobile;
import com.cg.onlinemobilerechargespringmvc.dto.RechargeTransaction;
import com.cg.onlinemobilerechargespringmvc.dto.Wallet;
import com.cg.onlinemobilerechargespringmvc.service.MobileRechargeService;

@Controller
public class Mycontroller {

	@Autowired
	MobileRechargeService mobilerechargeService;

	Customer customer;
	Wallet wall;

	@GetMapping("start")
	public String loginPage()
	{
		return "listPage";

	}

	@GetMapping("addpage")
	public ModelAndView getCustomer(@ModelAttribute("custm") Customer cust) 
	{
		
		return new ModelAndView("addcustomer");

	}

	@PostMapping("addcustomer")
	public ModelAndView addCustomer(@ModelAttribute("custm") Customer cust)
	{
 
		this.customer = cust;
	   // Customer customertwo=mobilerechargeService.addCustomer(cust);
		return new ModelAndView("success", "key", customer);
		// return new ModelAndView("AddMobile");

	}

	@GetMapping("addmobile")
	public ModelAndView addedmobile(@ModelAttribute("custm") Customer cust) 
	{
		return new ModelAndView("AddMobile"); // mobilenoadd

	}

	@PostMapping("addmobileno")
	public ModelAndView addmobile(@RequestParam("mobileno")String mobileno,
			@RequestParam("operator") String operator)
	{
		System.out.println(mobileno);
		Mobile mobii = new Mobile();
		List<Mobile> mobilist = new ArrayList<>();
		//System.out.println(operator);
       // BigInteger big=new BigInteger("1111");
		//mobii.setMobileno(big);
	     mobii.setMobileno(mobileno);
		 mobii.setOperator(operator);
		 mobii.setCustomer(customer);

		mobilist.add(mobii);
		Customer customerone = new Customer();
		customerone.setName(customer.getName());
		customerone.setEmail(customer.getEmail());

		customerone.setMobiles(mobilist);
		
		Customer customer = mobilerechargeService.addCustomer(customerone);
		return new ModelAndView("success","key",customer);   //success   mobilenoadd

	}

	@GetMapping("topupbalance")
	public ModelAndView topupbalance(@ModelAttribute("wall") Wallet wallet)
	{

		return new ModelAndView("topupbalance");

	}

	@PostMapping("addbalance")
	public ModelAndView addbalance(@ModelAttribute("wall") Wallet wallet)
	{
		this.wall=wallet;
		System.out.println(wall);
		Wallet wall=mobilerechargeService.topupBalance(wallet);
        return new ModelAndView("addbalance","key",wall);

	}

	@GetMapping("searchmobileno")
	public ModelAndView searchBymobile(@ModelAttribute("custm") Customer cust) 
	{

		return new ModelAndView("searchmobile");

	}

	@PostMapping("searchmobile")
	public ModelAndView listmoble(ModelAndView Model, @RequestParam("mobileno") String mobileno)
	{
		System.out.println("hii");
		List<Mobile>moblist;
		
		Customer cust= mobilerechargeService.searchByMobileno(mobileno);
	   Model.addObject("mobile", cust);
	   Model.setViewName("mobilesearch");
		System.out.println(cust);
		//return new ModelAndView("mobilesearch","mobile",cust);
		
		
		return Model;

		

		/* 
		Customer mobilesearch = mobilerechargeService.searchByMobileno(cust.getMobiles().toString());
		Model.addObject("mobile", mobilesearch);
		Model.setViewName("mobilesearch");
		return Model;

		// Customer customer=mobilerechargeService.searchByMobileno(cust.getMobiles());

		// return new ModelAndView("mobilesearch","searchmobile",custm);
*/	}

	@GetMapping("rechargemobile")
	public ModelAndView rechargemobile(@ModelAttribute("wall") Wallet wallet)
	{
		return new ModelAndView("rechargeMobile");

	}

	@PostMapping("rechargemob")
	public ModelAndView mobilerecharge(@RequestParam("TransactionId")BigInteger TransactionId,
			@RequestParam("amount")Double amount,@RequestParam("mobileno")String mobileno) 
	{


		RechargeTransaction transaction=new RechargeTransaction();
		List<RechargeTransaction>mylist=new ArrayList<>();
		
		transaction.setAmount(amount);
		transaction.setMobileno(mobileno);
		transaction.setTransactionId(TransactionId);
	
		
		
		mylist.add(transaction);
		
		Wallet wallet=new Wallet();
		wallet.setBalance(wall.getBalance());
		wallet.setCustomer(wall.getCustomer());
		wallet.setTransaction(wall.getTransaction());
		wallet.setWalletId(wall.getWalletId());
     
		
		wallet.setTransaction(mylist);
		RechargeTransaction walletone=mobilerechargeService.rechargeMobile(wallet);
	
		
		return new ModelAndView("Recharge","key",wallet); // result
	}

	@GetMapping("HOME")
	public String homepage() {
		return "listPage";
	}

}
