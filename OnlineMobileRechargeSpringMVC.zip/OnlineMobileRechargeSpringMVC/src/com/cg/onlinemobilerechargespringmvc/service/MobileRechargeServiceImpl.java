package com.cg.onlinemobilerechargespringmvc.service;



import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlinemobilerechargespringmvc.dao.MobileRechargeRepository;
import com.cg.onlinemobilerechargespringmvc.dao.MobileRechargeRepositoryImpl;
import com.cg.onlinemobilerechargespringmvc.dto.Customer;
import com.cg.onlinemobilerechargespringmvc.dto.RechargeTransaction;
import com.cg.onlinemobilerechargespringmvc.dto.Wallet;



@Service
@Transactional
public class MobileRechargeServiceImpl implements MobileRechargeService {

	
	@Autowired
	MobileRechargeRepository  repository;
	
	
	public MobileRechargeServiceImpl()
	{
		repository=new MobileRechargeRepositoryImpl();
	}
	

	@Override
	public Customer addCustomer(Customer custm) {

		repository.save(custm);
		
		
		return custm;
	}

	@Override
	public Wallet topupBalance(Wallet wall) {
		// TODO Auto-generated method stub
		return repository.saveWallet(wall);
	}

	@Override
	public Customer searchByMobileno(String mobileno) {
		// TODO Auto-generated method stub
		return repository.findByMobileno(mobileno);
	}

	@Override
	public RechargeTransaction rechargeMobile(Wallet wall) {
		// TODO Auto-generated method stub
		return repository.saveTransaction(wall);
	}

}
