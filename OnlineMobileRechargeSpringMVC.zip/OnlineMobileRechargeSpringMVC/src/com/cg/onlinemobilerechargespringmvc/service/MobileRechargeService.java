package com.cg.onlinemobilerechargespringmvc.service;




import com.cg.onlinemobilerechargespringmvc.dto.Customer;
import com.cg.onlinemobilerechargespringmvc.dto.RechargeTransaction;
import com.cg.onlinemobilerechargespringmvc.dto.Wallet;

public interface MobileRechargeService {

	public Customer addCustomer(Customer custm);
    public Wallet  topupBalance(Wallet wall);
	public Customer searchByMobileno(String mobileno)  ;
    public  RechargeTransaction rechargeMobile(Wallet wall) ;
	
}
	
	
