package com.cg.onlinemobilerecharge.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import com.cg.onlinemobilerecharge.dao.MobileRechargeRepository;
import com.cg.onlinemobilerecharge.dao.MobileRechargeRepositoryImpl;
import com.cg.onlinemobilerecharge.dto.Customer;
import com.cg.onlinemobilerecharge.dto.Mobile;
import com.cg.onlinemobilerecharge.dto.RechargeTransaction;
import com.cg.onlinemobilerecharge.dto.Wallet;
import com.cg.onlinemobilerecharge.util.DbUtil;
import com.onlinemobilerecharge.exception.MobileRechargeException;
import com.onlinemobilerecharge.exception.MobilenotFoundException;

public class MobileRechargeServiceImpl implements  MobileRechargeService 
{
	MobileRechargeRepository repository;
	
	  public MobileRechargeServiceImpl()
	  {
		  repository= new MobileRechargeRepositoryImpl();
	  }
	
	
	
	
	public boolean addCustomer(Customer custm)
	{
	    if(repository.save(custm))
		 {
	     	return true;
		 }
		   return false;	
	
	
	
	}
	
	public Wallet topupBalance(Wallet wall) {
	
		return  repository.saveWallet(wall);
	}


	  public Customer searchByMobileno(BigInteger mobileno) throws MobilenotFoundException
			
	{
		
		return repository.findByMobileno(mobileno);
	}

    public RechargeTransaction rechargeMobile(RechargeTransaction transaction)  throws MobileRechargeException 
    {
		
		return repository.saveTransaction(transaction);
	}

	
	
	
}
