package com.cg.onlinemobilerecharge.dto;

import java.math.BigDecimal;
import java.util.List;

public class Wallet
{

	
	
	public Wallet(double balance, Customer customer, Mobile mobile, String emailid) {
		super();
		this.balance = balance;
		this.customer = customer;
		this.mobile = mobile;
		this.emailid = emailid;
	}
	public Wallet()
	{
		super();

	}
	private double balance;
	private Customer customer;
	private Mobile mobile;
	private String emailid;

	public double getBalance()
	{
		return balance;
	}
	public void setBalance(double balance)
	{
		this.balance = balance;
	}
	public Customer getCustomer()
	{
		return customer;
	}
	public void setCustomer(Customer customer) 
	{
		this.customer = customer;
	}
	public Mobile getMobile()
	{
		return mobile;
	}
	public void setMobile(Mobile mobile)
	{
		this.mobile=mobile;
	}
	
	@Override
	public String toString() 
	{
		return "Wallet [balance=" + balance + ", customer=" + customer +  ",mobile=" + mobile +  "]";
	}
	public void setCustomer(List<Customer> custmlistOne) {
		// TODO Auto-generated method stub
		
	}
	public void setMobile(List<Mobile> mylist) {
		// TODO Auto-generated method stub
		
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
}
