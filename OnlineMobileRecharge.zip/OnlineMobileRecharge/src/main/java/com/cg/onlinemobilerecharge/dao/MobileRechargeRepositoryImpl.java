package com.cg.onlinemobilerecharge.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import com.cg.onlinemobilerecharge.dto.Customer;
import com.cg.onlinemobilerecharge.dto.Mobile;
import com.cg.onlinemobilerecharge.dto.RechargeTransaction;
import com.cg.onlinemobilerecharge.dto.Wallet;
import com.cg.onlinemobilerecharge.util.DbUtil;
import com.onlinemobilerecharge.exception.MobileRechargeException;
import com.onlinemobilerecharge.exception.MobilenotFoundException;

public class MobileRechargeRepositoryImpl implements MobileRechargeRepository
{
	
	
  	 Connection con;
	 ResultSet rs;
	public MobileRechargeRepositoryImpl()
	{
		  con=DbUtil.getConnection();
	}

		
      public boolean save(Customer custm) 
	   {
    	  
	   
		  try {
    	 
		   Mobile mobione=new Mobile();
		    String query_inserttwo="INSERT INTO Customer(name,email) VALUES(?,?)";
		
		
			 PreparedStatement pstm=con.prepareStatement (query_inserttwo);
			  pstm.setString(1, custm.getName());
			  pstm.setString(2, custm.getEmail());
			 
			
              pstm.executeUpdate();	
		  }
	
			catch (SQLException e) 
		 {
			
			e.printStackTrace();
		}
			
			 try {
				 
			       
			           for(Mobile m: custm.getMobiles()) 
			     
			           {
			        	   
			        	   String query_insert="INSERT INTO Mobile VALUES(?,?,?) ";
			        	   PreparedStatement   pstm1=con.prepareStatement (query_insert);
			        	   pstm1.setString(1, m.getMobileno().toString());
			        	   pstm1.setString(2,m.getOperator());
			        	   pstm1.setString(3,custm.getEmail());
						
				 		pstm1.executeUpdate();
			           }
			 }
				catch (SQLException e) 
			 {
				
				e.printStackTrace();
			}
			 finally
				{
				try {
					
					con.close();
				}catch( MobileRechargeException m){
					
					throw new  MobileRechargeException();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				}
			return false;
			
	   
	   
		 
	}

      public Wallet saveWallet(Wallet wall) 
      {	 
		Connection con=DbUtil.getConnection();
		 String query_insert="INSERT INTO Wallet VALUES(?,?,?) ";
		 
		 
		
		 try {
			 
			PreparedStatement pstm=con.prepareStatement (query_insert);
		
		   
		    pstm.setDouble(1,wall.getBalance());
		    pstm.setString(2, wall.getCustomer().getEmail());
		    pstm.setString(3,wall.getMobile().getMobileno().toString() );
		    pstm.executeUpdate();
		  
		 } catch (SQLException e) {
			
			e.printStackTrace();
		 }finally
			{
			try {
				
				con.close();
			}catch(SQLException e){
			
				throw new  MobileRechargeException();
			}
			}
		return wall;
	
	}

	public Customer findByMobileno(BigInteger mobileno) throws  MobilenotFoundException
	{		
           
             Connection con=DbUtil.getConnection();
             Customer custm=null;
    		// String query_insert="INSERT INTO Wallet VALUES(?,?) ";
            
    		 try {
            	 PreparedStatement pstm=con.prepareStatement ("SELECT c.name,c.email FROM Customer c join Mobile m  ON m.emailfk=c.email WHERE m.mobileno=?");
            	 pstm.setString(1, mobileno.toString());
            	 rs=pstm.executeQuery();
            	if(rs!=null) {
            		while(rs.next())
            		{
            			 custm=new Customer();
            			  custm.setName(rs.getString(1));
            			  custm.setEmail(rs.getString(2));
            			  
            		}
            	}
            	 
	            	 
             }catch(SQLException e) {
            	 
            	 e.printStackTrace();
             }finally
 			  {
     			try {
     				
     				con.close();
     			}catch(MobilenotFoundException m)
     			{
     				
     		   throw new  MobilenotFoundException("Mobile not found");
     			
     			} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
 			  }
		
		
             return custm;
	}


	public RechargeTransaction saveTransaction(RechargeTransaction transaction) throws MobileRechargeException
	{
		 
		
		Connection con=DbUtil.getConnection();
		
		try {
		    	 
			   Mobile mobione=transaction.getMobile();
			    String query_inserttwo="INSERT INTO rechargetransaction VALUES(?,?)";
			
			
				 PreparedStatement pstm=con.prepareStatement (query_inserttwo);
				  
				 pstm.setString(1, mobione.getMobileno().toString());
				  pstm.setDouble(2, transaction.getAmount());
				 
				
	              pstm.executeUpdate();	
			  }
		
				catch (SQLException e) 
			 {
				
				e.printStackTrace();
			}finally
				{
				try 
				{
					con.close();
				}catch(SQLException e){
					e.printStackTrace();
                    throw new  MobileRechargeException("recharge not done");
				}
	
		return transaction;
	}


	


	
	}

	
	 
}
