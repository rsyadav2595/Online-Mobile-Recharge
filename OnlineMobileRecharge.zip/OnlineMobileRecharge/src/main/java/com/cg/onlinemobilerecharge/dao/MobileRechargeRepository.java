package com.cg.onlinemobilerecharge.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import com.cg.onlinemobilerecharge.dto.Customer;
import com.cg.onlinemobilerecharge.dto.Mobile;
import com.cg.onlinemobilerecharge.dto.Wallet;

public interface MobileRechargeRepository {

	public boolean save(Customer custm);
    public Wallet saveWallet(BigDecimal  balance);
    public Mobile findByMobileno(BigInteger mobileno);
	
	
}
