package com.cg.onlinemobilerecharge.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import com.cg.onlinemobilerecharge.dto.Customer;
import com.cg.onlinemobilerecharge.dto.Mobile;
import com.cg.onlinemobilerecharge.dto.RechargeTransaction;
import com.cg.onlinemobilerecharge.dto.Wallet;
import com.onlinemobilerecharge.exception.MobileRechargeException;
import com.onlinemobilerecharge.exception.MobilenotFoundException;

public interface MobileRechargeRepository {

	public boolean save(Customer custm);
	public Wallet saveWallet(Wallet wall);
    public Customer findByMobileno(BigInteger mobileno) throws MobilenotFoundException;
    public RechargeTransaction saveTransaction(RechargeTransaction transaction) throws MobileRechargeException;
	
	
	
}
