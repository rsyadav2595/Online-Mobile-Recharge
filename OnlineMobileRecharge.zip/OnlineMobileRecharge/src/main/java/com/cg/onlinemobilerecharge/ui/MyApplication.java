package com.cg.onlinemobilerecharge.ui;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.onlinemobilerecharge.dto.Customer;
import com.cg.onlinemobilerecharge.dto.Mobile;
import com.cg.onlinemobilerecharge.dto.RechargeTransaction;
import com.cg.onlinemobilerecharge.dto.Wallet;
import com.cg.onlinemobilerecharge.service.MobileRechargeService;
import com.cg.onlinemobilerecharge.service.MobileRechargeServiceImpl;
import com.onlinemobilerecharge.exception.MobileRechargeException;
import com.onlinemobilerecharge.exception.MobilenotFoundException;

public class MyApplication {

	static  MobileRechargeService  service;
	public  MyApplication()
	{
		
	}
	
	public static void main(String[] args)
	{
        Scanner sc=new Scanner(System.in);	
	    service=new MobileRechargeServiceImpl();
	    int choice=0;
	    do {
	    	
	   
	    	printdetails();
	    	System.out.println("Enter choice");
	    	choice=sc.nextInt();
	    	switch(choice)
	    	{
	    	case 1:                                              ///Add Customer///
	    		 List<Mobile> mobiles=new ArrayList<>();
 		         System.out.println("Enter the name");
	    	     String name=sc.next();
	    	     System.out.println("Enter the email");
	    	    String email=sc.next();
	    	    String choice2="yes";
	    	    do {
	    	    	
	    	    	 Mobile mobi =new Mobile();
	    	    	  System.out.println("Enter the mobile no");
	  	    	    BigInteger mobile=sc.nextBigInteger();
	  	    	    System.out.println("enter operator");
	  	    	    String operator=sc.next();
	  	    	     
	 	    	    mobi.setMobileno(mobile);
	 	    	    mobi.setOperator(operator);
	 	    	     
	 	    	    
	 	    	     mobiles.add(mobi);
	 	    	     System.out.println("do you want to add more mobileno enter yes other no");
	 	    	     choice2=sc.next();
	 	    	     
	    	    }
	    	    while(choice2.equals("yes"));
	    	  
	    	   
	    	      Customer custm =new Customer();
	    	      custm.setName(name);
	     	      custm.setEmail(email);
 	    	      custm.setMobiles(mobiles);
	         	 service.addCustomer(custm);
	    	    break; 
	    	    

	                
	    	  case 2:                                                //create wallet or topup balance///
	    		   
	    		  Wallet wallet=new Wallet();
	    		  Customer custmone=new Customer();
	    	 
	    		  Mobile mob=new Mobile();
	    		  
	    		  System.out.println("Enter the balance");
                  Double balance=sc.nextDouble();
                 
                  System.out.println("Enter emailid");
                  String emailid=sc.next();               
                  
                   System.out.println("Enter mobile no");
                   BigInteger mobileone=sc.nextBigInteger();
                  
                    wallet.setBalance(balance);
                    custmone.setEmail(emailid);
                    wallet.setCustomer(custmone);
                 
                    
                    mob.setMobileno(mobileone);
                  wallet.setMobile(mob);
                 
                 
                  service.topupBalance(wallet);
                  
              
                   System.out.println("----------Wallet create successfuly----------");
  	      	 
	    	 break; 
	    		      
                   
              case 3:                                                             ////Search By mobileno///
                	try {
                		 Mobile mobbbi=new Mobile();
   	    	          System.out.println("Enter mobile no");
   	    	          BigInteger mobileno =sc.nextBigInteger();
   	    	         
   	    	          
   	    	          Customer  mobilesearch =service.searchByMobileno(mobileno);
   	    	          System.out.println(mobilesearch);
       	       
                	}catch(MobilenotFoundException m){
                		System.out.println(m.getMessage());
                	}
	    	    	 
	    	         break;
		   
	          case 4:                                                                        ///Recharge Transaction///
	        	  try {
	        		  RechargeTransaction recharge=new RechargeTransaction();
                      Mobile mobile=new Mobile();
    	             
                      System.out.println("Enter amount for mobile recharge");
    	              Double amount=sc.nextDouble();
    	             
    	               System.out.println("Enter mobile no  for recharge");
    	               BigInteger mobiletwo=sc.nextBigInteger();
    	              
    	               mobile.setMobileno(mobiletwo);
    	               recharge.setMobile(mobile);
    	               recharge.setAmount(amount);
    	             
    	              service.rechargeMobile(recharge);
    	              
      	  
    	 
    	                System.out.println("-----------recharge done-------"); 
	        	  }catch(MobileRechargeException m) {
	        		  System.out.println(m.getMessage());
	        	  }
	                    
	  	            break;	  
	    	    
	              }

	    	
	    
	               }  while(choice!=6); 
	    	
	             }


	private static void printdetails() 
	{
		System.out.println ("1. Add Customer");
		System.out.println("2. Topup balance");
		System.out.println("3. Search by mobile no");
		System.out.println("4. Reacharge mobile no");
		
	}
	
}
