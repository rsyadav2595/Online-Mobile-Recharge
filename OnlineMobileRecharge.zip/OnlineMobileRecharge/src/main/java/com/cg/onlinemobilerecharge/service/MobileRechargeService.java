package com.cg.onlinemobilerecharge.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import com.cg.onlinemobilerecharge.dto.Customer;
import com.cg.onlinemobilerecharge.dto.Mobile;
import com.cg.onlinemobilerecharge.dto.RechargeTransaction;
import com.cg.onlinemobilerecharge.dto.Wallet;
import com.onlinemobilerecharge.exception.MobileRechargeException;
import com.onlinemobilerecharge.exception.MobilenotFoundException;

public interface MobileRechargeService 
{

	public boolean addCustomer(Customer custm)throws  MobilenotFoundException;
    public Wallet  topupBalance(Wallet wall);
	public Customer searchByMobileno(BigInteger mobileno) throws  MobilenotFoundException ;
    public  RechargeTransaction rechargeMobile(RechargeTransaction transaction) throws MobileRechargeException     ;
	





}
