package com.cg.onlinemobilerecharge.util;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import com.cg.onlinemobilerecharge.dto.Customer;
import com.cg.onlinemobilerecharge.dto.Mobile;
import com.cg.onlinemobilerecharge.dto.Wallet;
import com.cg.onlinemobilerecharge.service.MobileRechargeServiceImpl;
public class DbUtil{


		static Connection con;
	public static Connection getConnection()
		{
			Properties prop=new Properties();
		try {
				InputStream in=new FileInputStream("src/main/resources/jdbc.properties");
				prop.load(in);
				
			
					if(prop!=null)
					{
						String driver =prop.getProperty("jdbc.driver");
						String url=prop.getProperty ("jdbc.url");
						String uname=prop.getProperty    ("jdbc.username" );					
				     	String upass=prop.getProperty("jdbc.password");
						Class.forName(driver);
						con=DriverManager.getConnection(url,uname,upass);
						
	 					}
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			//throw new EmpException("File not found");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	
		
		return con;
			
		}
		
}
	


	
	
	
	
	
	
	
	
	
	
	
	
	
	
