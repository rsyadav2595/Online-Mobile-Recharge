package com.cg.onlinemobilerecharge.dto;

import java.math.BigDecimal;
import java.util.List;

public class Wallet
{

	
	public Wallet(BigDecimal balance, Customer customer, Mobile mobile)
	{
		super();
		this.balance = balance;
		this.customer = customer;
		this.mobile=mobile;
		
	}
	public Wallet()
	{
		super();

	}
	private BigDecimal balance;
	private Customer customer;
	private Mobile mobile;

	public BigDecimal getBalance()
	{
		return balance;
	}
	public void setBalance(BigDecimal balance)
	{
		this.balance = balance;
	}
	public Customer getCustomer()
	{
		return customer;
	}
	public void setCustomer(Customer customer) 
	{
		this.customer = customer;
	}
	public Mobile getMobile()
	{
		return mobile;
	}
	public void setMobile(Mobile mobile)
	{
		this.mobile=mobile;
	}
	
	@Override
	public String toString() 
	{
		return "Wallet [balance=" + balance + ", customer=" + customer +  ",mobile=" + mobile +  "]";
	}
	public void setCustomer(List<Customer> custmlistOne) {
		// TODO Auto-generated method stub
		
	}
	public void setMobile(List<Mobile> mylist) {
		// TODO Auto-generated method stub
		
	}
}
