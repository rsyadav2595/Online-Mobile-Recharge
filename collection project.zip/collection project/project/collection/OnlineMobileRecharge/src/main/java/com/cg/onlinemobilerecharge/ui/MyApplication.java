package com.cg.onlinemobilerecharge.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.onlinemobilerecharge.dto.Customer;
import com.cg.onlinemobilerecharge.dto.Mobile;
import com.cg.onlinemobilerecharge.dto.RechargeTransaction;
import com.cg.onlinemobilerecharge.dto.Wallet;
import com.cg.onlinemobilerecharge.service.MobileRechargeService;
import com.cg.onlinemobilerecharge.service.MobileRechargeServiceImpl;
import com.cg.onlinemobilerecharge.util.DbUtil;

public class MyApplication {

	static  MobileRechargeService  service;
	public  MyApplication()
	{
		
	}
	
	public static void main(String[] args)
	{
        Scanner sc=new Scanner(System.in);	
	    service=new MobileRechargeServiceImpl();
	    int choice=0;
	    do {
	    	
	    	System.out.println(DbUtil.custmlistOne);
	    	printdetails();
	    	System.out.println("Enter choice");
	    	choice=sc.nextInt();
	    	switch(choice)
	    	{
	    	case 1:
	    		 List<Mobile> mobiles=new ArrayList<>();
 		         System.out.println("Enter the name");
	    	     String name=sc.next();
	    	     System.out.println("Enter the email");
	    	    String email=sc.next();
	    	    System.out.println("Enter the mobile no");
	    	    BigInteger mobile=sc.nextBigInteger();
	    	    System.out.println("ebnter operator");
	    	    String operator=sc.next();
	    	  
	    	    Mobile mobi =new Mobile();
	    	    mobi.setMobileno(mobile);
	    	    mobi.setOperator(operator);
	    	 
	    	    Customer custm =new Customer();
	    	    custm.setName(name);
	    	    custm.setEmail(email);
	    	    custm.setMobiles(mobiles);
	    	    
	    	    
	    	    
	              List<Mobile> mylist = DbUtil.mylist;
	              custm.setMobiles(mylist);
	              
	              List<Customer> custmlist = DbUtil.custmlistOne;
	              service.addCustomer(custm);
	        
	              
	    
	    
	              
	              break;
	                
	                
	    	  case 2: //create wallet or topup balance///
	    				     
               System.out.println("Enter the balance");
                BigDecimal balance=sc.nextBigDecimal();
                   // wallet.setBalance(balance);
                   System.out.println("Enter the customer");
                   String customer =sc.next();
                  System.out.println("Enter mobile no");  
                //  Mobile mobione =new Mobile();
  		           BigInteger mobileone=sc.nextBigInteger();
                 
  		         Wallet wall= service.createWallet(balance);
  		          

  		           
  		         for (Customer customerOne : DbUtil.custmlistOne) 
	    	      {
	    		  for (Mobile mobilesOne : customerOne.getMobiles()) {
					if(mobilesOne.getMobileno().equals( mobileone))
					{
						System.out.println("mobile no is "+ mobilesOne .getMobileno());
					}
						
				 }
   		     
	               service.topupBalance(balance);
  	    		  System.out.println("----------Wallet create succesfuly----------");
	    	      }	  
	    		 
                    
                    break;	  
	    		  
	    		  

	    	          	  	  
	    	  case 3:
	    	   System.out.println("Enter mobile no");
	    	   BigInteger mobileno =sc.nextBigInteger();
	    	   
	    	   Mobile mobilesearch =service.searchByMobileno(mobileno);
	  
	    	      for (Customer customerOne : DbUtil.custmlistOne) 
	    	      {
	    		  for (Mobile mobilesOne : customerOne.getMobiles()) {
					if(mobilesOne.getMobileno().equals(mobileno))
					{
						System.out.println("mobile no is "+ mobilesOne .getMobileno());
					}
						
				}
	    	
				System.out.println("mobile no is"+customerOne.getMobiles());
		
	    	   }    	   
   
	    	    break;
	   
	    	   
	          case 4:
	        	  
	         RechargeTransaction recharge=new RechargeTransaction();
	    	 System.out.println("Enter amount for mobile recharge");
	    	 BigDecimal amount=sc.nextBigDecimal();
	    	
	    	 System.out.println("Enter mobile no  for recharge");
	    	  BigInteger mobiletwo=sc.nextBigInteger();
	    	  
	    	     
	    	  for (Customer customerOne : DbUtil.custmlistOne) 
    	      {
    		  for (Mobile mobilesOne : customerOne.getMobiles()) {
				if(mobilesOne.getMobileno().equals(mobiletwo))
				{
					System.out.println("mobile no is "+ mobilesOne .getMobileno());
				}
					
			}
    	      }
	      	  
	    	 
	    	 System.out.println("-----------recharge done-------");
	  	        break;	  
	    	    
	    	}
	    	
	    
	    }  while(choice!=6); 
	    	
	    	
	    
			
			
			
			}


	private static void printdetails() 
	{
		System.out.println("1. Add Customer");
		//System.out.println("2. Create Wallet");
		System.out.println("2. Topup balance");
		System.out.println("3. Search by mobile no");
		System.out.println("4. Reacharge mobile no");
		
	}
	
}