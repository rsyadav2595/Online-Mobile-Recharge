import{Mobile} from'./app.Mobile';

 export class Customer{
 name:string;
email:string;
mobiles:Mobile[];
}