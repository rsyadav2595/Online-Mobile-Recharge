
import {Component,OnInit} from '@angular/core';
import{customerservice} from './app.customerservice';

@Component({
    selector:'mob-app',
    templateUrl:'searchmobile.html'
    
    })
      export class searchmobilecomponent{
      
        mobileno:string;

        Mobile:any;
        constructor(private custservice:customerservice)
    {

    }

    searchmobile()
        {
            console.log(this.mobileno);
            this.custservice.searchmobile(this.mobileno).subscribe((data:any)=>console.log(data));
            return this.custservice.searchmobile(this.mobileno).subscribe(data=>
                {this.Mobile=data;this.Mobile=Array.of(this.Mobile);});
        }


    
    }