import {Customer} from './app.customer';
import{Rechargetransaction} from './app.rechargetransaction';

export class Wallet{
    walletid:number;
    customer:Customer;
    balance:number;
    rechargetransaction:Rechargetransaction[];
}