﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import{Routes,RouterModule} from '@angular/router';
import{FormsModule} from '@angular/forms';
import{customercomponent}from './app.customercomponent';
import{walletcomponent} from './app.walletcomponent';
import{HttpClientModule} from '@angular/common/http' 
import { HttpModule } from '@angular/http';
import { searchmobilecomponent } from './app.searchmobilecomponent';
import { ReactiveFormsModule } from '@angular/forms';
import {NgxPaginationModule} from 'ngx-pagination';


const route:Routes=
[
     
{path:"addcustomer",component:customercomponent},  
{path:"addwallet",component:walletcomponent},
{path:"searchmobile",component:searchmobilecomponent},

];
@NgModule({
    imports: [
        BrowserModule,FormsModule,RouterModule.forRoot(route),HttpClientModule,HttpModule,ReactiveFormsModule
        ,NgxPaginationModule
    ],
    declarations: [
        AppComponent,walletcomponent,customercomponent,searchmobilecomponent
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { 
    
}