

 export  class Rechargetransaction{
    TransactionId:number;
    amount:number;
    mobileno:string;
    
}