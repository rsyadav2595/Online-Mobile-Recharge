import {Component,OnInit} from '@angular/core';
import{customerservice} from './app.customerservice';
import { Customer } from './app.customer';
import { Mobile } from './app.Mobile';

@Component({
selector:'cust-app',
templateUrl:'addcustomer.html'

})
  export class customercomponent{

    constructor (private custservice:customerservice){}
    model:any={};
    custmdata=false;
    mobiles:Mobile[]=[];
    mobile={
      
        operator:'',
        mobileno:''

    };

addcustm(){
     console.log(this.model);
     this.custmdata=true;
 }

addmobiles()
{
    this.mobiles.push(this.mobile);
    console.log(this.mobiles);
    this.mobile={
        operator:'',
        mobileno:''

    }
}
addAllCustomer()
{
    this.mobiles.push(this.mobile);
    this.model['mobiles']=this.mobiles;
    console.log(this.model);
    this.custservice.addAllCustomer(this.model).subscribe((data=>console.log(data)));
}



}



