import{Injectable} from '@angular/core';   //make class as servic

import {HttpClient, HttpHeaders, HttpParams}from '@angular/common/http'  //for getting data we put this 
import { Observable } from 'rxjs';
import { Customer} from './app.customer';
import { NgAnalyzedFileWithInjectables } from '@angular/compiler';
import { Http ,HttpModule} from '@angular/http'
import{throwError} from 'rxjs' ;
import{pipe} from 'rxjs';
import{catchError} from 'rxjs/operators';


@Injectable({

providedIn:'root'

})

 export class customerservice{
//call json file here//

constructor(private http:HttpClient) {} //injecting all predefined  methode from httpclientmodule 
//options={
   // headers:new HttpHeaders({
       // 'Access.Control.Allow-Headers':'content-Type',
       // 'Access.Control.Allow-Methods':'GET ,POST,PUT,DELETE,OPTIONS',
       // 'Access.Control.Allow-Origin' :'*'

    //})
//}

addAllCustomer(custm:any):any
{   
    var input=new FormData() ;
    let i:number=0;
  input.append("name",custm.name);
  input.append("email",custm.email);
  console.log(custm);
   while(i<custm.mobiles.length){
      console.log(i);
      input.append("mobiles["+i+"].operator",custm.mobiles[i].operator);
      input.append("mobiles["+i+"].mobileno",custm.mobiles[i].mobileno);
      i++;
  } 
    return this.http.post("http://localhost:9062/onlinemob/addcustomer",input);
}

addWallet(wall:any):any
{
   
var input=new FormData();
    let i:number=0;
   input.append("walletId",wall.walletId);
   input.append("balance",wall.balance);
   input.append("customer.email",wall.customeremail);


console.log(wall);

while(i< wall.rechargetransactions.length)
{

    console.log(i);

   input.append("transaction["+i+"].TransactionId",wall.rechargetransactions[i].TransactionId) ; 
   input.append("transaction["+i+"].amount",wall.rechargetransactions[i].amount) ; 
   input.append("transaction["+i+"].mobileno",wall.rechargetransactions[i].mobileno) ;    
   i++;                                  
}
   return  this.http.post("http://localhost:9062/onlinemob/addwallet",input);
}

searchmobile(mobileno:string)

{
    //let params=new HttpParams().set("mobileno",mobileno);
console.log(mobileno);
return  this.http.get("http://localhost:9062/onlinemob/search?mobileno="+mobileno).pipe(catchError(this.handleError));

}


handleError(error){
    let message="";
    message='Mobile not found!';
    window.alert(message);
    return throwError(message);
    } 


 }