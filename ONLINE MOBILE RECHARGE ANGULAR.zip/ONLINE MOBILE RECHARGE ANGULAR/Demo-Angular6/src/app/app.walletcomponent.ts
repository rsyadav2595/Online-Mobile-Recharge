import {Component,OnInit} from '@angular/core';
import{customerservice} from './app.customerservice';
import { Wallet } from './app.wallet';
import { Rechargetransaction} from './app.rechargetransaction';

@Component({
    selector:'wall-app',
    templateUrl:'addwallet.html'
    
    })
      export class walletcomponent{
    

        constructor (private custservice:customerservice){}
        model:any={};
        walletdata=false;
        rechargetransactions:Rechargetransaction[]=[];

    rechargetransaction:Rechargetransaction=new Rechargetransaction();
   // {

   // TransactionId: 0,
  //  amount:0,
//mobileno:''
//};
      
addtrans()
{
    console.log(this.model);
    this.walletdata=true;
}
addtransactions()
{

    this.rechargetransaction.TransactionId=this.model.TransactionId;
    this.rechargetransaction.amount=this.model.amount;
    this.rechargetransaction.mobileno=this.model.mobileno;
    this.rechargetransactions.push(this.rechargetransaction);
    console.log(this.rechargetransactions);
    this.rechargetransaction={
        TransactionId:0,
        amount:0,
        mobileno:''
    }
}


addWallet()
{

   // this.model['rechargetransactions']=this.rechargetransactions;
   this.model.rechargetransactions=this.rechargetransactions;
    console.log(this.model);
    this.custservice.addWallet(this.model).subscribe((data=>console.log(data)));
}

}