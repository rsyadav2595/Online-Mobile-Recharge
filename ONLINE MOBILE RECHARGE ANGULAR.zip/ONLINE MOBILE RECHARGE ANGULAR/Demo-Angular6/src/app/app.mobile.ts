



 export class Mobile{
 operator:string;
 mobileno:string;
}