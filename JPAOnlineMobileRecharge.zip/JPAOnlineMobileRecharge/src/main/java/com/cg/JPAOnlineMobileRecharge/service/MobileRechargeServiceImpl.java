package com.cg.JPAOnlineMobileRecharge.service;

import java.math.BigInteger;

import com.cg.JPAOnlineMobileRecharge.dao.MobileRechargeRepository;
import com.cg.JPAOnlineMobileRecharge.dao.MobileRechargeRepositoryImpl;
import com.cg.JPAOnlineMobileRecharge.dto.Customer;
import com.cg.JPAOnlineMobileRecharge.dto.RechargeTransaction;
import com.cg.JPAOnlineMobileRecharge.dto.Wallet;

public class MobileRechargeServiceImpl implements  MobileRechargeService  {

	
	MobileRechargeRepository  repository;
	
	public MobileRechargeServiceImpl()
	{
		repository=new MobileRechargeRepositoryImpl();
	}
	
	
	public boolean addCustomer(Customer custm)
	{
		
		repository.save(custm);
		
		return false;
	}

	public Wallet topupBalance(Wallet wall)
	{
				return repository.saveWallet(wall);
	}

	public Customer searchByMobileno(BigInteger mobileno) {
		
		return repository.findByMobileno(mobileno);
	}

	public RechargeTransaction rechargeMobile(Wallet wall) 
	{


		return repository.saveTransaction(wall);
	}

}
