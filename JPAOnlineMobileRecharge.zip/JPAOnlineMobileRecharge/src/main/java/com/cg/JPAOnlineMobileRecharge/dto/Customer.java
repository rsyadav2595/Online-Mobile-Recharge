package com.cg.JPAOnlineMobileRecharge.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;


@Entity
public class Customer
{ 
	@Id
	@Column(name="customer_emailid")
	 private String email;
	
	@Column(name="customer_name")
	private String name;
	
	
	@OneToMany(cascade=CascadeType.ALL)
	@JoinColumn(name="customer_email")
	private List<Mobile> mobiles;
	   
	 
	 
	public Customer(String name, String email, List<Mobile> mobiles) {
		super();
		this.name = name;
		this.email = email;
		this.mobiles = mobiles;
		
	}
	public Customer() 
	{
		super();

	}
	
	   public String getName() 
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getEmail()
	{
		return email;
	}
	public void setEmail(String email)
	{
		this.email = email;
	}
	public List<Mobile> getMobiles() 
	{
		return mobiles;
	
	}
	public void setMobiles(List<Mobile> mobiles)
	{
		this.mobiles = mobiles;
	}
	
	public void add(Customer custm) {

	}
	
	@Override
	public String toString() {
		return "Customer [name=" + name + ", email=" + email + ", mobiles=" + mobiles + "]";
	}
	
}
