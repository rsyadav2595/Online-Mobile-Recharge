package com.cg.JPAOnlineMobileRecharge.dto;

import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity



public class RechargeTransaction 
{
    
	
	public RechargeTransaction(BigInteger transactionId, double amount, BigInteger mobileno) {
		super();
		TransactionId = transactionId;
		this.amount = amount;
		this.mobileno = mobileno;
	}

	@Id
	@Column(name="transId")
	private BigInteger TransactionId;
	
	@Column(name="amount")
	private double amount;
	
	
  
private BigInteger mobileno;

	
	

	
	public RechargeTransaction() 
	{
			super();
			// TODO Auto-generated constructor stub
		}

	
	public double getAmount()
	{
		return amount;
	}
	public void setAmount(double amount)
	{
		this.amount = amount;
	}
	
	
	 public BigInteger getTransactionId() {
		return TransactionId;
	}

    public void setTransactionId(BigInteger transactionId) {
		TransactionId = transactionId;
	}


	public BigInteger getMobileno() {
		return mobileno;
	}


	public void setMobileno(BigInteger mobileno) {
		this.mobileno = mobileno;
	}


	@Override
	public String toString() {
		return "RechargeTransaction [TransactionId=" + TransactionId + ", amount=" + amount + ", mobileno=" + mobileno
				+ "]";
	}



	




	}

