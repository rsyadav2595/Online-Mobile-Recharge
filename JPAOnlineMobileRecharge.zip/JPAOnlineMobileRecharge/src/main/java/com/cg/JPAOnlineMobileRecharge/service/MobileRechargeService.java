package com.cg.JPAOnlineMobileRecharge.service;

import java.math.BigInteger;

import com.cg.JPAOnlineMobileRecharge.dto.Customer;
import com.cg.JPAOnlineMobileRecharge.dto.RechargeTransaction;
import com.cg.JPAOnlineMobileRecharge.dto.Wallet;
import com.cg.JPAOnlineMobileRecharge.exception.MobileRechargeException;
import com.cg.JPAOnlineMobileRecharge.exception.MobilenotFoundException;



public interface MobileRechargeService {
	public boolean addCustomer(Customer custm);
    public Wallet  topupBalance(Wallet wall)throws MobileRechargeException;
	public Customer searchByMobileno(BigInteger mobileno) throws MobilenotFoundException  ;
    public  RechargeTransaction rechargeMobile(Wallet wall) throws MobileRechargeException;
	
}
