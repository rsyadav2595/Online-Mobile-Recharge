package com.cg.JPAOnlineMobileRecharge.ui;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.JPAOnlineMobileRecharge.dto.Customer;
import com.cg.JPAOnlineMobileRecharge.dto.Mobile;
import com.cg.JPAOnlineMobileRecharge.dto.RechargeTransaction;
import com.cg.JPAOnlineMobileRecharge.dto.Wallet;
import com.cg.JPAOnlineMobileRecharge.exception.MobileRechargeException;
import com.cg.JPAOnlineMobileRecharge.exception.MobilenotFoundException;
import com.cg.JPAOnlineMobileRecharge.service.MobileRechargeService;
import com.cg.JPAOnlineMobileRecharge.service.MobileRechargeServiceImpl;



public class MyApplication {
	static  MobileRechargeService  service;
	
	public  MyApplication()
	{
		
	}
	   
	public static void main(String[] args)
		{
	        Scanner sc=new Scanner(System.in);	
		    service=new MobileRechargeServiceImpl();
		    Wallet wallet=new Wallet();
		    int choice=0;
		    do {
		    	
		   
		    	printdetails();
		    	System.out.println("Enter choice");
		    	choice=sc.nextInt();
		    	switch(choice)
		    	{
		    	case 1:                                                        ///Add Customer///
		    		 List<Mobile> mobiles=new ArrayList<Mobile>();
	 		         System.out.println("Enter the name");
		    	     String name=sc.next();
		    	     System.out.println("Enter the email");
		    	    String email=sc.next();
		    	    String choice2="yes";
		    	    do {
		    	    	
		    	    	 Mobile mobi =new Mobile();
		    	    	  System.out.println("Enter the mobile no");
		  	    	    BigInteger mobile=sc.nextBigInteger();
		  	    	    System.out.println("enter operator");
		  	    	    String operator=sc.next();
		  	    	     
		 	    	    mobi.setMobileno(mobile);
		 	    	    mobi.setOperator(operator);
		 	    	     
		 	    	    
		 	    	     mobiles.add(mobi);
		 	    	     System.out.println("do you want to add more mobileno enter yes other no");
		 	    	     choice2=sc.next();
		 	    	     
		    	    }
		    	    while(choice2.equals("yes"));
		    	  
		    	   
		    	      Customer custm =new Customer();
		    	      custm.setName(name);
		     	      custm.setEmail(email);
	 	    	      custm.setMobiles(mobiles);
		         	 service.addCustomer(custm);
		    	  
		         	 break; 
		    	    

		                
		    	  case 2:                                                //create wallet or topup balance///
		    		   
		    		
		    		  Customer custmone=new Customer();
		    	   try {
		    		     Mobile mob=new Mobile();
			    		// List< Mobile> moblist=new  ArrayList<Mobile>();
			    		  System.out.println("Enter walletId");
			    		  BigInteger walletid=sc.nextBigInteger();
			    		  
			    		  
			    		  System.out.println("Enter the balance");
		                  Double balance=sc.nextDouble();
		                  
		                   System.out.println("Enter emailid");
	                       String emailid=sc.next();               
	                  
	                        wallet.setBalance(balance);
		                    wallet.setWalletId(walletid);
		                    custmone.setEmail(emailid);
		                
		                    wallet.setCustomer(custmone);
		                    wallet.setCustomer(custmone);
		                    
			                 service.topupBalance(wallet);
			                 System.out.println("----------Wallet create successfuly----------");
		    	       }  catch (MobileRechargeException m) {
		    		          System.out.println(m.getMessage());
			      	}
		    		 
	                    
	         	 break; 
		    		      
	                   
	              case 3:                                                             ////Search By mobileno///
	                	try {
	                		 Mobile mobbbi=new Mobile();
	                		
	                		// Customer custtwo=new Customer();
	   	    	            
	                		 System.out.println("Enter mobile no");
	   	    	             BigInteger mobileno =sc.nextBigInteger();
	   	    	         
	   	    	              //  Mobile mobilesearch=service.searchByMobileno(mobileno);
	   	    	              Customer  mobilesearch =service.searchByMobileno(mobileno);
	   	    	              System.out.println(mobilesearch);
	       	       
	   	    	           //   System.out.println(custtwo.getEmail());
	   	    	              
	   	    	              
	                	    }catch(MobilenotFoundException m)
	                      	  {
	                		     System.out.println(m.getMessage());
	                     	   }
		    	    	 
		    	         break;
			   
		          case 4:                                                                        ///Recharge Transaction///
		        	  try {
		        		  
		        		    String choice1="yes ";
		        		    List<RechargeTransaction> mylist=new ArrayList<RechargeTransaction>();
	                   
		        		  do {
		        		  RechargeTransaction recharge=new RechargeTransaction();
	                      System.out.println("Enter transactionId");
	                      BigInteger transactionid=sc.nextBigInteger();
	                      
	                      System.out.println("Enter mobile no  for recharge");
    	                  BigInteger mobiletwo=sc.nextBigInteger();
	    	              
	                      
	                      System.out.println("Enter amount for mobile recharge");
	    	              Double amount=sc.nextDouble();
	    	              recharge.setAmount(amount);
	    	              recharge.setMobileno(mobiletwo);
	    	              recharge.setTransactionId(transactionid);
	    	              mylist.add(recharge);
	    	              System.out.println("do u want again recharge yes or no");
	    	              choice1=sc.next();
		        		  }
		        		  while(choice1.equals("yes"));
		        		  wallet.setTransaction(mylist);
                          service.rechargeMobile(wallet);
	    	               System.out.println("-----------recharge done-------"); 
		        	    
		          	    }   catch(MobileRechargeException m) {
		        	  }
		                    
		  	            break;	  
		    	    
		              }
                        }  while(choice!=6); 
		    	
		             }


		private static void printdetails() 
		{
			System.out.println ("1. Add Customer");
			System.out.println("2. Topup balance");
			System.out.println("3. Search by mobile no");
			System.out.println("4. Reacharge mobile no");
			
		}
	}


