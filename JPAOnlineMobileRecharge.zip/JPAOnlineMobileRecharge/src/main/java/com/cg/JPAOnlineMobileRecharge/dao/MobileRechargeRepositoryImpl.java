package com.cg.JPAOnlineMobileRecharge.dao;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.JPAOnlineMobileRecharge.dto.Customer;
import com.cg.JPAOnlineMobileRecharge.dto.Mobile;
import com.cg.JPAOnlineMobileRecharge.dto.RechargeTransaction;
import com.cg.JPAOnlineMobileRecharge.dto.Wallet;
import com.cg.JPAOnlineMobileRecharge.exception.MobileRechargeException;
import com.cg.JPAOnlineMobileRecharge.exception.MobilenotFoundException;
import com.cg.JPAOnlineMobileRecharge.util.DbUtil;

public class MobileRechargeRepositoryImpl implements MobileRechargeRepository   
{
        EntityManager em ;
	
	   public MobileRechargeRepositoryImpl()
	   {
		   em = DbUtil.getConnection();
	   }
	
	  public boolean save(Customer custm)
	   {
			em.getTransaction().begin();
			em.persist(custm);
		    em.getTransaction().commit();
		    return false;
	  }

	public Wallet saveWallet(Wallet wall)throws MobileRechargeException
	{
	   try {
		   
		   em.getTransaction().begin();
		   em.persist(wall);
		   em.getTransaction().commit();
		    }catch (Exception e) {
			  throw new MobileRechargeException("balance not added");
			  }	     
	
	return wall;
		}

	public Customer findByMobileno(BigInteger mobileno) throws MobilenotFoundException
	{ 
		try {
			  List<Mobile>mobilelist =new ArrayList<Mobile>();
			Customer custm=null;
             String sql="FROM Mobile  WHERE mobileno=:mobileno";
			 TypedQuery<Mobile>query=em.createQuery(sql,Mobile.class);
			 query.setParameter("mobileno", mobileno);
		      Mobile mobilesearch=query.getSingleResult();
		  	 return custm;
			
		}catch (MobilenotFoundException m)
		{
			throw new MobilenotFoundException("number not found");
		}
	
		
	}

	public RechargeTransaction saveTransaction(Wallet wall) throws MobileRechargeException
	{
		
		try {
			 List<RechargeTransaction> transaction=wall.getTransaction();
			// RechargeTransaction transactionone=null;
			 for (RechargeTransaction rechargeTransaction : transaction) {
				em.getTransaction().begin();
			  Query query=em.createNativeQuery("INSERT INTO rechargetransaction VALUES (?,?,?,?)");
			
			  query.setParameter(1, rechargeTransaction.getTransactionId());
	          query.setParameter(2, rechargeTransaction.getAmount());
			  query.setParameter(3, wall.getWalletId());
			  query.setParameter(4, rechargeTransaction.getMobileno());
			  query.executeUpdate();
			  em.getTransaction().commit();
		    	  }
		  }catch (MobileRechargeException m)
		    {
			throw new MobileRechargeException("recharge not done");
		    }			
	
		return null;
	//	return saveTransaction(wall);
	}

}
