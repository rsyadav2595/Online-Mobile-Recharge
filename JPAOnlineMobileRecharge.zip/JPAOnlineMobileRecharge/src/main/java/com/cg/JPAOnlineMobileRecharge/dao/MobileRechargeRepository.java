package com.cg.JPAOnlineMobileRecharge.dao;

import java.math.BigInteger;

import com.cg.JPAOnlineMobileRecharge.dto.Customer;
import com.cg.JPAOnlineMobileRecharge.dto.RechargeTransaction;
import com.cg.JPAOnlineMobileRecharge.dto.Wallet;
import com.cg.JPAOnlineMobileRecharge.exception.MobileRechargeException;
import com.cg.JPAOnlineMobileRecharge.exception.MobilenotFoundException;


public interface MobileRechargeRepository {
	public boolean save(Customer custm);
	public Wallet saveWallet(Wallet wall)throws MobileRechargeException;
    public Customer findByMobileno(BigInteger mobileno)throws MobilenotFoundException    ;
    public RechargeTransaction saveTransaction(Wallet wall) throws MobileRechargeException;
}
